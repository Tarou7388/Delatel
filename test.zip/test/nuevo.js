const fs = require('fs');

function convertDates(sql) {
    return sql.replace(/'\b(\d{2})-(\d{2})-(\d{4})\b'/g, (match, day, month, year) => {
        return `'${year}-${month}-${day}'`;
    });
}

const sql = `INSERT INTO tb_contratos (id_cliente, id_paquete, id_sector, id_usuario_registro, direccion_servicio, referencia, ficha_instalacion, coordenada, fecha_inicio, fecha_registro, fecha_fin, nota, create_at)
VALUES (195, 55, 1, 1, 'ENTRADA CONDORILLO PSJ GONZALES PRADA 205', 'NINGUNA', NULL, '-13.430269, -76.114939', '2023-03-08', NOW(), NULL, 'NINGUNA', NOW()),
       (504, 58, 28, 1, 'PSJ. JASMIN S/N, MINA DE ORO - SUNAMPE', 'NINGUNA',NULL,'-13.4257887,-76.1454569','08-03-2023',NOW(),NULL, 'NINGUNA', NOW()),
       (505, 58, 28, 1, 'Av. San Antonio - Santa Rosa - Sunampe', 'NINGUNA',NULL,'-13.421591, -76.157187', '08-03-2023',NOW(),NULL, 'NINGUNA', NOW()),
       (506, 48, 1, 1, 'Av.melchorita 506 - grocio prado','NINGUNA',NULL,'-13.4026499,-76.1583898','14-03-2023',NOW(),NULL, 'NINGUNA', NOW()),
       (507, 55, 1, 1, 'AV. San ignacio 147 - Sunampe', 'NINGUNA',NULL,'-13.419536590576172,-76.1566390991211','16-03-2023',NOW(),NULL, 'NINGUNA', NOW()),
       (509, 55, 1, 1, 'Calle Santa tereza 281-Sunampe', 'NINGUNA',NULL,'-13.4262836,-76.1660506', '20-03-2023',NOW(),NULL, 'NINGUNA', NOW()),
       (510, 55, 1, 1, 'Calle La Victoria 247 - Sunampe','NINGUNA',NULL,'-13.4301417,-76.170455','21-03-2023',NOW(),NULL, 'NINGUNA', NOW()),
       (90, 48, 1, 1, 'Av.fatima última cuadra ','pasando bodega Viña San Francisco',NULL,NULL,'29-03-2023',NOW(),NULL, 'NINGUNA', NOW()),
       (410, 48, 1, 1, 'AA.HH. VIRGEN DEL CARMEN MZ. L LT. 26- Cruz Blanca','NINGUNA',NULL,'-13.427320, -76.123391','31-03-2023',NOW(),NULL, 'NINGUNA', NOW()),
       (514, 48, 1, 1, 'AA.HH. VIRGEN DEL CARMEN MZ. H LT. 02 - CRUZ BLANCA','NINGUNA',NULL,'-13.427440, -76.123965', '04-04-2023',NOW(),NULL,'NINGUNA', NOW()),
       (306, 55 , 1 , 1 , 'Ulises San Valentín manzana Gn Lote 4- Condorillo' , 'NINGUNA' , NULL , '-13.4330174,-76.1199143' , '04-04-2023' , NOW() ,NULL , 'NINGUNA' , NOW()),
       (516, 48, 1, 1, 'Psj Sucre espalda del estadio mina de oro', 'BARRIO MELCHORITA II ',NULL,'-13.407278,-76.1614213', '14-04-2023',NOW(),NULL, 'NINGUNA', NOW()),
       (492, 48, 1, 1, 'CL. SAN ANTONIO S/N','NINGUNA',NULL,'-13.4301417,-76.170455','21-03-2023',NOW(),NULL, 'NINGUNA', NOW()),
       (283, 58, 1, 1, 'AV. PRINCIPAL S/N, HUACA GRANDE', 'NINGUNA',NULL,NULL,'17-04-2023',NOW(),NULL, 'NINGUNA', NOW());`;

const modifiedSql = convertDates(sql);

fs.writeFileSync('output.sql', modifiedSql);

console.log('Archivo SQL generado: output.sql');