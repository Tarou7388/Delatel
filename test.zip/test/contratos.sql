USE Delatel;

SELECT ct.id_cliente, ct.id_contrato, p.nombres, p.apellidos, p.nro_doc
FROM
    tb_contratos ct
    RIGHT JOIN tb_clientes cl ON ct.id_cliente = cl.id_cliente
    RIGHT JOIN tb_personas p ON cl.id_persona = p.id_persona;

SELECT * FROM tb_personas;

SELECT * FROM tb_contratos WHERE id_cliente = 582;

UPDATE tb_contratos SET ficha_instalacion = * WHERE id_contrato = 1;