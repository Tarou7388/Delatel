<?php

require_once "../app/models/Conexion.php";

class ModeloControlador extends Conexion
{
  private $pdo;

  public function __construct()
  {
    $this->pdo = Conexion::getConexion();
  }
}

$objeto = new ModeloControlador();

if (isset($_GET["operacion"])) {
  $operacion = $_GET["operacion"];
  switch ($operacion) {
    case "buscarCLiente":
      $sql = "SELECT c.id_cliente FROM tb_clientes c INNER JOIN tb_personas p ON c.id_persona = p.id_persona WHERE p.nombres LIKE ? OR p.apellidos LIKE ?";
      $params = ["%" . $_GET["nombre"] . "%", "%" . $_GET["apellido"] . "%"];
      $resultado = $objeto->consultaParametros($sql, $params);
      echo json_encode($resultado);
      break;
    case "buscarPaquete":
      $sql = "SELECT * FROM tb_paquetes WHERE paquete LIKE ?";
      $params = ["%" . $_GET["nombre"] . "%"];
      $resultado = $objeto->consultaParametros($sql, $params);
      echo json_encode($resultado);
      break;
    case "buscarZona":
      $sql = "SELECT * FROM tb_sectores WHERE sector LIKE ?";
      $params = ["%" . $_GET["nombre"] . "%"];
      $resultado = $objeto->consultaParametros($sql, $params);
      echo json_encode($resultado);
      break;
    case "buscarContrato":
      $sql = "SELECT CONCAT(p.apellidos, ' ', p.nombres) as person_nombre, c.id_cliente FROM tb_personas p LEFT JOIN tb_clientes c ON p.id_persona = c.id_persona WHERE CONCAT(p.apellidos, '', p.nombres) LIKE ?";
      $params = ["%" . $_GET["nombre"] . "%"];
      $resultado = $objeto->consultaParametros($sql, $params);
      if(count($resultado) == 0){
        echo json_encode(["mensaje" => "No se encontraron resultados Persona"]);
        return;
      }
      $sql = "SELECT * FROM tb_paquetes WHERE paquete LIKE ?";
      $params2 = ["%" . $_GET["plan"] . "%"];
      $resultado2 = $objeto->consultaParametros($sql, $params2);

      if(count($resultado2) == 0){
        echo json_encode(["mensaje" => "No se encontraron resultados Paquete"]);
        return;
      }
      $sql = "SELECT * FROM tb_contratos WHERE id_cliente = ? AND id_paquete = ?";
      $params3 = [$resultado[0]["id_cliente"], $resultado2[0]["id_paquete"]];
      $resultado3 = $objeto->consultaParametros($sql, $params3);
      if(count($resultado3) == 0){
        echo json_encode(["mensaje" => "No se encontraron resultados Contrato"]);
        return;
      }


      echo json_encode($resultado3);
  }
}
