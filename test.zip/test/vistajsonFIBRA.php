<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generador de JSON</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            max-width: 1400px;
            /* Increased from default 1140px */
            width: 95%;
            /* Added to make it responsive but still wider */
        }

        h1,
        h2 {
            color: #007bff;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .btn {
            width: 100%;
            padding: 12px;
            font-size: 1.1rem;
        }

        pre {
            background-color: #f4f4f4;
            padding: 20px;
            border-radius: 5px;
            border: 1px solid #ddd;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
    </style>
</head>

<body>

    <div class="container mt-5">
        <h1 class="text-center">Generador de JSON para Fibra Óptica</h1>
        <div class="row">
            <div class="col-md-8">

                <form id="jsonForm">
                    <!-- Periodo -->
                    <div class="form-group">
                        <label for="periodo">Periodo:</label>
                        <input type="text" class="form-control" id="periodo" name="periodo">
                    </div>

                    <!-- Fibra Óptica -->
                    <h2>Fibra Óptica</h2>
                    <div class="row">
                        <div class="col-md-4 form-group">
                            <label for="usuario">Usuario:</label>
                            <input type="text" class="form-control" id="usuario" name="usuario">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="claveacceso">Clave de Acceso:</label>
                            <input type="password" class="form-control" id="claveacceso" name="claveacceso">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="vlan">VLAN:</label>
                            <input type="number" class="form-control" id="vlan" name="vlan" value="22">
                        </div>
                    </div>
                    <div class="row" hidden>
                        <div class="col-md-4 form-group">
                            <label for="potencia">Potencia:</label>
                            <input type="number" class="form-control" id="potencia" name="potencia">
                        </div>
                    </div>

                    <!-- Router -->
                    <h2>Router</h2>
                    <div class="row" hidden>
                        <div class="col-md-4 form-group">
                            <label for="ssid">SSID:</label>
                            <input type="text" class="form-control" id="ssid" name="ssid" value="DELATEL01">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="seguridad">Seguridad:</label>
                            <input type="text" class="form-control" id="seguridad" name="seguridad" value="DELATEL01">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="codigobarra">Código de Barra:</label>
                            <input type="text" class="form-control" id="codigobarra" name="codigobarra" value="123456">
                        </div>
                    </div>
                    <div class="row" hidden>
                        <div class="col-md-4 form-group">
                            <label for="ip">IP:</label>
                            <input type="text" class="form-control" id="ip" name="ip" value="192.168.0.1">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="marca">Marca:</label>
                            <input type="text" class="form-control" id="marca" name="marca" value="DESCONOCIDO">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="modelo">Modelo:</label>
                            <input type="text" class="form-control" id="modelo" name="modelo" value="DESCONOCIDO">
                        </div>
                    </div>
                    <div class="row" hidden>
                        <div class="col-md-4 form-group">
                            <label for="serie">Serie:</label>
                            <input type="text" class="form-control" id="serie" name="serie" value="A1B2C3">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="banda">Banda:</label>
                            <input type="text" class="form-control" id="banda" name="banda" value="2.4,5">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="numeroantena">Número de Antenas:</label>
                            <input type="number" class="form-control" id="numeroantena" name="numeroantena" value="3">
                        </div>
                    </div>
                    <div class="row" hidden>
                        <div class="col-md-4 form-group form-check">
                            <input type="checkbox" class="form-check-input" id="catv" name="catv">
                            <label class="form-check-label" for="catv">CATV</label>
                        </div>
                    </div>
                    <div class="row" hidden>
                        <div class="col-md-4 form-group">
                            <label for="ingresouserrouter">Ingreso Usuario Router:</label>
                            <input type="text" class="form-control" id="ingresouserrouter" name="ingresouserrouter" value="admin">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="ingresopass">Ingreso Contraseña:</label>
                            <input type="password" class="form-control" id="ingresopass" name="ingresopass" value="Gpon26">
                        </div>
                    </div>

                    <!-- Tipo de Entrada -->
                    <h2>Tipo de Entrada</h2>
                    <div class="row" hidden>
                        <div class="col-md-4 form-group">
                            <label for="puerto">Puerto:</label>
                            <input type="number" class="form-control" id="puerto" name="puerto" value="0">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="idcaja">ID Caja:</label>
                            <input type="number" class="form-control" id="idcaja" name="idcaja" value="0">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="numRepetidores">Número de Repetidores:</label>
                            <input type="number" class="form-control" id="numRepetidores" name="numRepetidores" onchange="addRepetidorFields()">
                        </div>
                    </div>

                    <div id="repetidoresContainer"></div>

                    <button type="button" class="btn btn-primary" onclick="generateJSON()">Generar JSON</button>
                </form>
            </div>

            <div class="col-md-4">
                <h2>JSON Generado</h2>
                <pre id="jsonOutput" class="bg-light p-3"></pre>
                <button class="btn btn-secondary mt-2" onclick="copyToClipboard()">Copiar al Portapapeles</button>
            </div>

            <script>
                function copyToClipboard() {
                    const jsonOutput = document.getElementById('jsonOutput').textContent;
                    navigator.clipboard.writeText(jsonOutput).then(() => {
                        console.log('Texto copiado al portapapeles');
                    }).catch(err => {
                        console.error('Error al copiar al portapapeles: ', err);
                    });
                }
            </script>
        </div>
    </div>

    <!-- Nueva sección de tabla en su propio container -->
    <div class="container mt-4">
        <div class="row">
            <!-- Tabla de contratos -->
            <div class="col-md-8">
                <table class="table table-bordered" id="contratosTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Cliente</th>
                            <th>Plan</th>
                            <th>Fecha</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
            <div class="col-md-4">
                <div class="card p-3">
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombre</label>
                        <input type="text" id="nombre" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="plan" class="form-label">Plan</label>
                        <input type="text" id="plan" class="form-control">
                    </div>
                    <button class="btn btn-primary" id="buscar">Guardar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        let idcontrato = 0;

        function addRepetidorFields() {
            const numRepetidores = parseInt(document.getElementById('numRepetidores').value) || 0;
            const container = document.getElementById('repetidoresContainer');
            container.innerHTML = '';

            for (let i = 0; i < numRepetidores; i++) {
                const repetidorHTML = `
                <h3>Repetidor ${i + 1}</h3>
                <div class="row">
                    <div class="col-md-4 form-group">
                        <label for="ssid${i}">SSID:</label>
                        <input type="text" class="form-control" id="ssid${i}" name="ssid${i}">
                    </div>
                    <div class="col-md-4 form-group">
                        <label for="seguridad${i}">Seguridad:</label>
                        <input type="text" class="form-control" id="seguridad${i}" name="seguridad${i}">
                    </div>
                    <div class="col-md-4 form-group">
                        <label for="codigobarra${i}">Código de Barra:</label>
                        <input type="text" class="form-control" id="codigobarra${i}" name="codigobarra${i}">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 form-group">
                        <label for="ip${i}">IP:</label>
                        <input type="text" class="form-control" id="ip${i}" name="ip${i}">
                    </div>
                    <div class="col-md-4 form-group">
                        <label for="marca${i}">Marca:</label>
                        <input type="text" class="form-control" id="marca${i}" name="marca${i}">
                    </div>
                    <div class="col-md-4 form-group">
                        <label for="modelo${i}">Modelo:</label>
                        <input type="text" class="form-control" id="modelo${i}" name="modelo${i}">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 form-group">
                        <label for="serie${i}">Serie:</label>
                        <input type="text" class="form-control" id="serie${i}" name="serie${i}">
                    </div>
                    <div class="col-md-4 form-group">
                        <label for="banda${i}">Banda:</label>
                        <input type="text" class="form-control" id="banda${i}" name="banda${i}">
                    </div>
                    <div class="col-md-4 form-group">
                        <label for="numeroantena${i}">Número de Antenas:</label>
                        <input type="number" class="form-control" id="numeroantena${i}" name="numeroantena${i}">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 form-group form-check">
                        <input type="checkbox" class="form-check-input" id="catv${i}" name="catv${i}">
                        <label class="form-check-label" for="catv${i}">CATV</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 form-group">
                        <label for="ingresouserrouter${i}">Ingreso Usuario Router:</label>
                        <input type="text" class="form-control" id="ingresouserrouter${i}" name="ingresouserrouter${i}">
                    </div>
                    <div class="col-md-4 form-group">
                        <label for="ingresopass${i}">Ingreso Contraseña:</label>
                        <input type="password" class="form-control" id="ingresopass${i}" name="ingresopass${i}">
                    </div>
                </div>
            `;
                container.insertAdjacentHTML('beforeend', repetidorHTML);
            }
        }

        function generateJSON() {
            const form = document.getElementById('jsonForm');
            const formData = new FormData(form);
            const routerData = {
                ssid: formData.get('ssid'),
                seguridad: formData.get('seguridad'),
                codigobarra: formData.get('codigobarra'),
                ip: formData.get('ip'),
                marca: formData.get('marca'),
                modelo: formData.get('modelo'),
                serie: formData.get('serie'),
                banda: formData.get('banda').split(','),
                numeroantena: parseInt(formData.get('numeroantena')),
                catv: formData.get('catv') === 'on',
                ingresouserrouter: formData.get('ingresouserrouter'),
                ingresopass: formData.get('ingresopass')
            };

            const numRepetidores = parseInt(formData.get('numRepetidores')) || 0;
            const repetidores = [];

            for (let i = 0; i < numRepetidores; i++) {
                repetidores.push({
                    ssid: formData.get(`ssid${i}`),
                    seguridad: formData.get(`seguridad${i}`),
                    codigobarra: formData.get(`codigobarra${i}`),
                    ip: formData.get(`ip${i}`),
                    marca: formData.get(`marca${i}`),
                    modelo: formData.get(`modelo${i}`),
                    serie: formData.get(`serie${i}`),
                    banda: formData.get(`banda${i}`).split(','),
                    numeroantena: parseInt(formData.get(`numeroantena${i}`)),
                    catv: formData.get(`catv${i}`) === 'on',
                    ingresouserrouter: formData.get(`ingresouserrouter${i}`),
                    ingresopass: formData.get(`ingresopass${i}`)
                });
            }

            //sumar 6 meses a la fecha del periodo
            const fecha = new Date(formData.get('periodo'));
            const mes = fecha.getMonth() + 6;
            const anio = fecha.getFullYear();
            const dia = fecha.getDate();
            const fechaFinal = new Date(anio, mes, dia);
            const fechaFinalString = `${fechaFinal.getFullYear()}-${(fechaFinal.getMonth() + 1).toString().padStart(2, '0')}-${fechaFinal.getDate().toString().padStart(2, '0')}`;
            formData.set('periodo', fechaFinalString);

            const data = {
                periodo: formData.get('periodo'),
                fibraoptica: {
                    usuario: formData.get('usuario'),
                    claveacceso: formData.get('claveacceso'),
                    potencia: parseInt(formData.get('potencia')),
                    router: routerData,
                    detalles: "",
                    repetidores: repetidores
                },
                idcaja: parseInt(formData.get('idcaja')),
                vlan: parseInt(formData.get('vlan')),
                puerto: parseInt(formData.get('puerto'))
            };
            //que se muestre: UPDATE tb_contratos SET ficha_tecnica = 'JSON' WHERE id_contrato = 1;
            console.log(data);
            document.getElementById('jsonOutput').textContent = `UPDATE tb_contratos SET ficha_instalacion = '${JSON.stringify(data)}' WHERE id_contrato = ${idcontrato};`;
        }

        async function buscarContrato() {
            const nombre = document.getElementById('nombre').value;
            const plan = document.getElementById('plan').value;

            // Aquí puedes agregar la lógica para buscar el contrato en tu base de datos
            // y mostrar los resultados en la tabla o en otro lugar.

            console.log(`Buscando contrato para ${nombre} con plan ${plan}`);
            const response = await fetch(`./modeloControlador.php?operacion=buscarContrato&nombre=${nombre}&plan=${plan}`)
            const data = await response.json();
            console.log(data);
            const tableBody = document.querySelector("#contratosTable tbody");
            tableBody.innerHTML = ""; // Limpiar la tabla antes de agregar nuevos resultados
            if (!data.mensaje) {
                idcontrato = data[0].id_contrato;
                document.querySelector("#periodo").value = data[0].fecha_inicio;
                data.forEach(contrato => {
                    const row = document.createElement("tr");
                    row.innerHTML = `
                    <td>${contrato.id_contrato}</td>
                    <td>${contrato.id_cliente}</td>
                    <td>${contrato.id_paquete}</td>
                    <td>${contrato.fecha_inicio}</td>
                `;
                    tableBody.appendChild(row);
                });
            }

        }

        document.querySelector("#buscar").addEventListener("click", buscarContrato);
    </script>

</body>

</html>