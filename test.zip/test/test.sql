INSERT INTO tb_contratos (id_cliente, id_paquete, id_sector,id_usuario_registro, id_usuario_tecnico, direccion_servicio, referencia, ficha_instalacion, coordenada, fecha_inicio, fecha_registro,fecha_fin, nota, create_at) VALUES
(100, 58, 1, 1, 1, 'Calle 1', 'Referencia 1', NULL, '-13.4172191,-76.1566138', '26-09-2022', NOW(), NULL, 'NINGUNA', NOW()),
(100, 58, 1, 1, 1, 'Calle Miguel Grau #513- Sunampe ', 'Ref: Carretera de Sunampe , frente a la bodega Chumbiauca', NULL, -13.4172191,-76.1566138, '2022-09-26', NOW(), NULL, 'NINGUNA', NOW()),
(629, AQUI, 30, 1, 1, 'PSJ. RAMON CASTILLA N° 135 - SUNAMPE (CHACARITA)', 'PSJ. RAMON CASTILLA N° 135 - SUNAMPE (CHACARITA)', NULL, '13, 76', '2023-12-20', NOW(), NULL, 'NINGUNA', NOW());

DROP DATABASE Delatel;


UPDATE tb_contratos 
SET fecha_inicio = CASE 
    WHEN fecha_inicio REGEXP '^[0-9]{2}-[0-9]{2}-[0-9]{4}$' 
    THEN STR_TO_DATE(fecha_inicio, '%d-%m-%Y')
    ELSE fecha_inicio 
END;

SELECT * FROM tb_contratos ;

UPDATE tb_contratos SET ficha_instalacion = "*" WHERE id_contrato = 1;