<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Formulario de Ingreso</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
  <div class="container mt-5">
    <h2>Formulario de Ingreso</h2>
    <form id="form" method="post">
      <div class="form-group">
        <label for="nombre">Nombre:</label>
        <input type="text" class="form-control" id="nombre" name="nombre" required>
      </div>
      <div class="form-group">
        <label for="direccion">Dirección:</label>
        <input type="text" class="form-control" id="direccion" name="direccion" required>
      </div>
      <div>
        <label for="referencia">Referencia:</label>
        <input type="text" class="form-control" id="referencia" name="referencia" required>
      </div>
      <div class="form-group">
        <label for="plan">Plan:</label>
        <input type="text" class="form-control" id="plan" name="plan" required>
      </div>
      <div class="form-group">
        <label for="fechainstalado">Fecha Instalado:</label>
        <input type="text" class="form-control" id="fechainstalado" name="fechainstalado" required>
      </div>
      <div class="form-group">
        <label for="coordenadas">Coordenadas:</label>
        <input type="text" class="form-control" id="coordenadas" name="coordenadas" required>
      </div>
      <div class="form-group">
        <label for="zona">Zona:</label>
        <input type="text" class="form-control" id="zona" name="zona" required>
      </div>
      <button type="submit" class="btn btn-primary">Enviar</button>
    </form>
    <div>
      <h3>Resultado</h3>
      <p id="resultado"></p>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
<script>
  document.querySelector("#form").addEventListener("submit", async function(e) {
    e.preventDefault();

    let coordenadas = document.querySelector("#coordenadas").value.trim();
    let coordenadassi = coordenadas;

    // Función para convertir DMS a decimal
    function convertirDMSaDecimal(coordenada) {
      const regex = /^(\d+)°(\d+)'([\d.]+)"([NSEW])$/;
      const match = coordenada.match(regex);

      if (!match) return parseFloat(coordenada); // Si ya está en decimal, devolver el valor

      let grados = parseInt(match[1]);
      let minutos = parseInt(match[2]);
      let segundos = parseFloat(match[3]);
      let direccion = match[4];

      let decimal = grados + minutos / 60 + segundos / 3600;

      // Si es Sur o Oeste, el valor debe ser negativo
      if (direccion === "S" || direccion === "W") {
        decimal *= -1;
      }

      return decimal;
    }

    // Verificar si la coordenada tiene formato DMS
    if (/°/.test(coordenadas)) {
      const partes = coordenadas.split(" ");
      if (partes.length === 2) {
        let latitudDecimal = convertirDMSaDecimal(partes[0]);
        let longitudDecimal = convertirDMSaDecimal(partes[1]);
        coordenadassi = `${latitudDecimal}, ${longitudDecimal}`;
      }
    }

    // Obtener otros valores del formulario
    const nombreCompleto = document.querySelector("#nombre").value;
    const palabras = nombreCompleto.split(" ");
    const apellido = palabras.slice(0, 2).join(" ");
    const nombre = palabras.slice(2).join(" ");

    const responseidnombre = await fetch(`modeloControlador.php?operacion=buscarCLiente&nombre=${nombre}&apellido=${apellido}`);
    const dataidnombre = await responseidnombre.json();
    console.log("nombre", dataidnombre);

    const responseidpaquete = await fetch(`modeloControlador.php?operacion=buscarPaquete&nombre=${document.querySelector("#plan").value}`);
    const dataidpaquete = await responseidpaquete.json();
    console.log("paquete", dataidpaquete);

    const responseidzona = await fetch(`modeloControlador.php?operacion=buscarZona&nombre=${document.querySelector("#zona").value}`);
    const dataidzona = await responseidzona.json();
    console.log("zona", dataidzona);

    const fechaSQL = document.querySelector("#fechainstalado").value.split("/").reverse().join("-");
    document.querySelector("#fechainstalado").value = fechaSQL;

    if (document.querySelector("#coordenadas").value === "") {
      document.querySelector("#coordenadas").value = "NULL";
    }

    function validarId(id) {
      if (Array.isArray(id) && id.length === 0) {
        return "AQUI";
      }
      return id[0]; // Si tiene datos, tomamos el primer elemento y seguimos normal
    }

    let idCliente = validarId(dataidnombre);
    let idPaquete = validarId(dataidpaquete);
    let idSector = validarId(dataidzona);

    if (idCliente === "AQUI") {
      alert("no se ha encontrato el cliente, Busque de manera manual. Lo siento D:");
    }else{
      idCliente = idCliente.id_cliente;
    }
    if (idPaquete === "AQUI") {
      alert("no se ha encontrato el paquete, Busque de manera manual. Lo siento D:");
    }else{
      idPaquete = idPaquete.id_paquete;
    }
    if (idSector === "AQUI") {
      alert("no se ha encontrato el sector, Busque de manera manual. Lo siento D:");
    }else{
      idSector = idSector.id_sector;
    }

    const parte1 = `(${idCliente}, ${idPaquete}, ${idSector}, 1, 1, `;
    const parte2 = `'${document.querySelector("#direccion").value}', '${document.querySelector("#referencia").value}', `;
    const parte3 = `NULL, '${coordenadassi}', '${document.querySelector("#fechainstalado").value}', `;
    const parte4 = `NOW(), NULL, 'NINGUNA', NOW()),`;
    const texto = parte1 + parte2 + parte3 + parte4;
    document.querySelector("#resultado").textContent = texto;
  });
</script>


</html>